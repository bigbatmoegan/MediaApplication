// N220 Section 28299
// Jeremy Morgan
// Week 5: Arrays and Objects
// September 29 2019


'use strict';

//create dragon
let dragon = {

    //name of dragon
    name: "Pete",

    //happiness meter
    happiness: 50,

    //energy meter
    energy: 50

};

//feed function
function feed() {

    //add 2 to energy
    dragon.energy= dragon.energy+2;

    //subtract 1 from happiness
    dragon.happiness=dragon.happiness-1;

    //refresh values
    refresh();
}

//play function
function play() {

    //add 2 to happiness
    dragon.happiness=dragon.happiness+2;

    //subtract 2 to energy
    dragon.energy=dragon.energy-2; 

    //refresh values
    refresh();
}

//refresh function
function refresh () {
    //select the dragon div
    let myDiv=document.querySelector("#dragon");
    
    //show new happiness value and energy value
    myDiv.innerHTML="Happiness: " + dragon.happiness + " Energy: " + dragon.energy;

    //show new energy value
   // myDiv.innerHTML=dragon.energy;

    //check if either is below 35
    if(dragon.energy <35) {

        //change background color to red
        myDiv.style.backgroundColor= "red";
    }

    //set color back to normal
    else {
        //set color
        myDiv.style.backgroundColor= "green";
    }

}


//set default values
function main() {
    //access the dragon div
    let myDiv=document.querySelector("#dragon");
    //show the starting values
    myDiv.innerHTML="Happiness: " + dragon.happiness + " Energy: " + dragon.energy;
}