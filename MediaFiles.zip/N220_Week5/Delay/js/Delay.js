// N220 Section 28299
// Jeremy Morgan
// Week 5: Arrays and Objects
// September 29 2019


'use strict';

function main() {

    //create a variable to use to output
    let output=document.querySelector("#dvOutput");

    //create a variable for number of bad words
    let badWords=0;
    //get the user sentence
    var sentence=document.querySelector("#sentence").value;
         
    //conver to lower case string
    let sentence2=sentence.toLowerCase();

    //conver string to array
    let sentenceSplit=sentence2.split(" ");

    //loop through the array
    for(let x=0; x<sentenceSplit.length; x++) {
            
    //check current word to see if its bad
        if(sentenceSplit[x]=='it' || sentenceSplit[x]=='snow' || sentenceSplit[x]=='chevy') {
            //increase the number of bad word counter by 1
            badWords++;
        }
    }
    //if no bad words are found
    if(badWords==0) {
        //print out that no words are found
        print("No bad words found!");
    }
        
    //if bad words are found
    else {
            //print out bad words were found
        print("Uh oh, bad words were found!");

        //print the number of bad words
        print("Number of bad words: " + badWords);

    }
    //clear the input field
    document.getElementById('sentence').value="";

}

//function to print to the DOM
function print(string) {
    //print to the DOM
    dvOutput.innerHTML += string + "<br>";
}