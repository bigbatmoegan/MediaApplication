// N220 Section 28299
// Jeremy Morgan
// Week 5: Arrays and Objects
// September 29 2019

'use strict';

//create a function to calculate the sum then average
function calculate() {

    // create array of scores
    let highScores=[12, 23, 42, 52, 67, 81, 92];

    //create a variable to hold total
    let total=0;

    // iterate through the array
    for (let x=0; x<highScores.length; x++) {

        //store all of the scores
        total=total+highScores[x];
    }
    //create div for output
    let myDiv=document.querySelector("#sum");

    //output sum
    myDiv.innerHTML=returnTotal(total);

    //calculate average
    total=total/highScores.length;

    //make new div for average
    let myDiv2=document.querySelector("#average");

    //output average 
    myDiv2.innerHTML=returnTotal(total);
}

//create a function to return number as string
function returnTotal (x) {

    //convert to string
    let xString= ""+ x;
    
    //return value
    return xString;
}

//empty main function as its not used
function main() {
    

}