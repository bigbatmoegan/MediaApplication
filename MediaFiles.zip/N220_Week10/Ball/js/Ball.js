//
//  N220 Section 28299
//  Jeremy Morgan
//  Week 10: Animation
//  30 October 2019
//

//declare ball
let ball = {
    //radius of the circle
    _radius: 75,
    //starting x value
    _xPos: 0,
    //starting y value
    _yPos: 300,
    //ball velocity
    _velocity: 05,
    //ball x speed
    _speedx: 04,
    //ball x speed
    _speedy: 04

}

//setup function
function setup() {
    //create the canvas
    createCanvas(800,600);

}

function draw() {

    //color background
    background(120);
    //draw ball
    circle(ball._xPos, ball._yPos, ball._radius);
    //color in the ball
    fill(0,0,255);
    //check if the ball is at the far left of screen
    if(ball._xPos > 800) {
        //change magnitude so the ball bounces back
        ball._speedx=ball._speedx * -1;
    }
    //check if the ball is at the far right of the screen
    else if(ball._xPos < 0) {
        //change magnitude so the ball bounces back
        ball._speedx=ball._speedx * -1;
    }
    //check if the ball is at the bottom of the screen
    else if(ball._yPos > 600){
        //change magnitude so the ball bounces back
        ball._speedy=ball._speedy * -1;
    }
    //check if the ball is at the top of the screen
    else if(ball._yPos < 0) {
        //change magnitude so the ball bounces back
        ball._speedy=ball._speedy * -1;
    }
    //update the x location of the ball
    ball._xPos=ball._xPos+ball._speedx;
    //update the y location of the ball
    ball._yPos=ball._yPos+ball._speedy;
}