//
//  N220 Section 28299
//  Jeremy Morgan
//  Week 10: Animation
//  30 October 2019
//

//declare ball
let ball = {
    //ball radius
    _radius: 75,
    //ball's x starting position
    _xPos: 400,
    //ball's y starting position
    _yPos: 300,

}

//setup function
function setup() {
    //create the canvas
    createCanvas(800,600);

}

//draw function
function draw() {
    //color background
    background(120);
    //draw ball
    circle(ball._xPos, ball._yPos, ball._radius);
    //color the ball blue
    fill(0,0,255);
    //check if a key is pressed
    if(keyIsPressed) {
        //see if the right arrow is pressed
        if(keyCode == RIGHT_ARROW) {
            //check if at corresponding boundary
            if(ball._xPos==799) {
                //send to the left of the screen
                ball._xPos=0;
            }
            //if not at right side
            else{
                //move by 1 pixel
                ball._xPos++;
            }
        }
        //see if the left arrow is pressed
        else if(keyCode == LEFT_ARROW) {
            //check if at corresponding boundary
            if(ball._xPos==1) {
                //send to the right of the screen
                ball._xPos=800;
            }
            else{
                //move by 1 pixel
                ball._xPos--;
            }
        }
        //see if the up arrow is pressed
        else if(keyCode == UP_ARROW) {
            //check if at corresponding boundary
            if(ball._yPos==0) {
                //send to the bottom of the screen
                ball._yPos=599;
            }
            else{
                //move by 1 pixel
                ball._yPos--;
            }
        }
        //see if the down arrow is pressed
        else if(keyCode == DOWN_ARROW) {
            //check if at corresponding boundary
            if(ball._yPos==599) {
                //send to the top of the screen
                ball._yPos=0;
            }
            else{
                //move by 1 pixel
                ball._yPos++;
            }
        }
    }
}