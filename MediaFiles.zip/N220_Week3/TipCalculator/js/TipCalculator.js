// N220 Section 28299
// Jeremy Morgan
// Week 3: Functions and Inputs
// September 15 2019

'use strict';


function calculate() {

    let output = document.querySelector("#dvOutput");
    let amount = document.querySelector("#amtTxt");

    let realAmount=amount.value;
    let intRealAmount = parseInt(realAmount, 10);
    if (realAmount != 0) {

        let tip = realAmount * 0.20;
        let total = intRealAmount+tip;


        print("Tip: " + tip);
        print("Total: " + total);

    }

    else {
        print("Please enter a value")
    }
}


function print(message) {

    dvOutput.innerHTML += message + "<br>";
}
function main() {
    

}
