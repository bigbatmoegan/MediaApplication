// N220 Section 28299
// Jeremy Morgan
// Week 3: Functions and Inputs
// September 15 2019


'use strict';


function login() {

    let output = document.querySelector("#dvOutput");
    let username = document.querySelector("#username");
    let password = document.querySelector("#password");

    let realUsername=username.value;
    let realPassword=password.value;

    if (realUsername == "username" && realPassword == "Pa$$w0rd") {
        print("Access Granted");
    }
    else {
        print("Access Denied");
    }
}


function print(message) {

    dvOutput.innerHTML += message + "<br>";
}
function main() {
    

}