// N220 Section 28299
// Jeremy Morgan
// Week 3: Functions and Inputs
// September 15 2019

'use strict';


function sayHello() {

    let output = document.querySelector("#dvOutput");
    let name = document.querySelector("#NameTxt");

    let realName=name.value;

    print("Hello");
    print("Your name is: " + realName);
    if (realName == "Jeremy Morgan") {
        print("Hey wait a minute that's my name!");
    }
}


function print(message) {

    dvOutput.innerHTML += message + "<br>";
}
function main() {
    

}