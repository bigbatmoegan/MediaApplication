//
//  N220 Section 28299
//  Jeremy Morgan
//  Week 11: Animation and Arrays
//  November 9 2019
//

//declare ball
let ball = {
    //radius of the circle
    _radius: 75,
    //starting x values
    _xPos: [],
    //starting y values
    _yPos: [],
    //ball velocity array
    _velocity: [0, 1, 2, 3, 4, 5]

}

//setup function
function setup() {
    //create the canvas
    createCanvas(800,600);

}

function draw() {

    //color background
    background(120);
    //fill arrays with random starting values
    for (let x=0; x<20; x++) {
        //generate a random x starting value
        let xstart=Math.floor(Math.random()*799 +1);
        //add to the array containing x values
        ball._xPos[x]=xstart;
        //generate a random y starting value
        let ystart=Math.floor(Math.random()*599 +1);
        //add to the array containing y values
        ball._yPos[x]=ystart;
    }
    //loop to draw the balls
    for(let i=0; i<ball._xPos.length; i++) {
        //draw the ball
        circle(ball._xPos[i], ball._yPos[i], ball._radius);
        //color the ball
        fill(0, 255, 0); 
    }
    //loop to move the balls
    for(let j=0; j<ball._xPos.length; j++) {
        //get a random velocity amount
        let vel=Math.floor(Math.random()*6 +1);
        //update the x location of the ball
        ball._xPos[j]=ball._xPos[j]+vel;
        //update the y location of the ball
        ball._yPos[j]=ball._yPos[j]+vel;
    }
}