//
//  N220 Section 28299
//  Jeremy Morgan
//  Week 11: Animation and Arrays
//  November 9 2019
//

//declare ball
let ball = {
    //radius of the circle
    _radius: 75,
    //starting x valuess
    _xPos: [200, 0, 750],
    //starting y values
    _yPos: [300, 500, 100],
    //ball velocity
    _velocity: 05,
    //ball x speeds
    _speedx: [04, 04, 04],
    //ball x speeds
    _speedy: [04, 04, 04]

}

//setup function
function setup() {
    //create the canvas
    createCanvas(800,600);

}

function draw() {

    //color background
    background(120);
    //loop and create the three balls
     // had a problem i thought was caused with the loops
    // so i declared the iterators before each loop so they
    //would reset each draw call, but i dont think it caused
    //the problem, but dont want to mess it up.
    //declare loop iterator
    let i=0;
    //declare loop iterator
    let k=0;
    //declare loop iterator
    let j=0;
    //loop to create 3 balls
    for(i; i<ball._xPos.length; i++) {
        //draw the ball
        circle(ball._xPos[i], ball._yPos[i], ball._radius);
        //color the ball
        fill(0, 0, 255);
    }
    // loop to check the boundaries
    for(k; k<ball._xPos.length; k++) {
        //check if the ball is at the far left of screen
        if(ball._xPos[k] > 800) {
            //change magnitude so the ball bounces back
            ball._speedx[k]=ball._speedx[k] * -1;
        }
        //check if the ball is at the far right of the screen
        else if(ball._xPos[k] < 0) {
            //change magnitude so the ball bounces back
            ball._speedx[k]=ball._speedx[k] * -1;
        }
        //check if the ball is at the bottom of the screen
        else if(ball._yPos[k] > 600){
            //change magnitude so the ball bounces back
            ball._speedy[k]=ball._speedy[k] * -1;
        }
        //check if the ball is at the top of the screen
        else if(ball._yPos[k] < 0) {
            //change magnitude so the ball bounces back
            ball._speedy[k]=ball._speedy[k] * -1;
        }
    } 
    //loop to move the balls
    for(j; j<ball._xPos.length; j++) {
        //update the x location of the ball
        ball._xPos[j]=ball._xPos[j]+ball._speedx[j];
        //update the y location of the ball
        ball._yPos[j]=ball._yPos[j]+ball._speedy[j];
    }
}