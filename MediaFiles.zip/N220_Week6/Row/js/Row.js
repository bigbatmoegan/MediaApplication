// N220 Section 28299
// Jeremy Morgan
// Week 6: Events
// October 7 2019


'use strict';


//declare main function
function main() {
    //create a variable for first div
    let first = document.querySelector("#first");

    //create a variable for second div
    let second = document.querySelector("#second");

    //create a variable for third div
    let third = document.querySelector("#third");

    //
}

//create event function
function changeColor(event) {

    //create variable to manipulate the color
    let temp= event.target.getAttribute("id");

    //determine which Id you have using switchcases
    switch(temp) {

        //check for first div
        case "first":

            //get access to frist div
            let myDiv=document.querySelector("#first");

            //change to appropriate color
            myDiv.style.backgroundColor="red";

            //end case
            break;

        //check for second case
        case "second":

            //get access to second div
            let myDiv2=document.querySelector("#second");

            //change to appropriate color
            myDiv2.style.backgroundColor="green";

            //end case
            break;

        //check for third case
        case "third":

            //get access to third div
            let myDiv3=document.querySelector("#third");

            //change to appropriate color
            myDiv3.style.backgroundColor="blue";

            //end case
            break;
    }
}