// N220 Section 28299
// Jeremy Morgan
// Week 6: Events
// October 7 2019


'use strict';

//declare change shirt function
function changeShirt(event) {

    //get shirt number from event
    let temp=event.target.getAttribute("data-shirt");

    //create a switch case base off of shirt#
    switch(temp){

        //determine if shirt number is 1
        case "1":

            //get access to the image
            let myImg=document.getElementById("shirt");

            //change to the next shirt in the list
            myImg.src="images/char_shirt2.png";

            //get access to the images attributes
            let myImgCount=document.querySelector("#shirt");

            //change the shirt number to 2
            myImgCount.setAttribute("data-shirt", "2");

            //break out of case
            break;
        
        //Determine if shirt number is 2
        case "2":
            
            //get access to the image
            let myImg2=document.getElementById("shirt");

            //change to the next shirt in the list
            myImg2.src="images/char_shirt3.png";

            //get access to the images attributes
            let myImgCount2=document.querySelector("#shirt");

            //change the shirt number to 3
            myImgCount2.setAttribute("data-shirt", "3");

            //break out of case
            break;

        //Determine if shirt number is 3
        case "3":

            //get access to the image
            let myImg3=document.getElementById("shirt");

            //loop to first shirt in list
            myImg3.src="images/char_shirt1.png";

            //get access to the images attributes
            let myImgCount3=document.querySelector("#shirt");

            //change shirt number to 1
            myImgCount3.setAttribute("data-shirt", "1");

            //break out of case
            break;
    }
}