// N220 Section 28299
// Jeremy Morgan
// Week 5: Arrays and Objects
// September 29 2019

'use strict';
//global variable of red
let r=0;

//global variable of greed
let g=0;

//global variable of blue
let b=0;

//declare main function
function main() {
    
    //get access to the display grid
    let temp=document.querySelector("#display");

    //set the div to show the color black
    temp.innerHTML="rgb(0,0,0)";
}

//declare the +1 function
function changeValue1(event) {

    //get access to the display grid
    let displayDiv=document.querySelector("#display");

    //get access to the color div
    let color=document.querySelector("#changer");

    //get the color attribute from the button that was clicked
    let type=event.target.getAttribute("data-color");

    //switch cases based off of the color 
    switch(type) {

        //if the color is red
        case "red":
            
            //increase value of red by 1
            r=r+1;

            //create a color string
            let colorstring="rgb("+r+","+g+","+b+")";

            //create a color string
            color.style.backgroundColor=colorstring;

            //update listed color values
            displayDiv.innerHTML=colorstring;

            //break out of case
            break;

        //if the color is green
        case "green":

            //increase value of green by 1
            g=g+1;
            //create a color string
            let colorstring2="rgb("+r+","+g+","+b+")";
            //set color grid to the new value of the color
            color.style.backgroundColor=colorstring2;
             //update listed color values
            displayDiv.innerHTML=colorstring2;
            //break out of case
            break;

        //if the color is blue
        case "blue":
            //increase the value of blue by 1
            b=b+1;
            //create a color string
            let colorstring3="rgb("+r+","+g+","+b+")";
            //set color grid to the new value of the color
            color.style.backgroundColor=colorstring3;
            //update listed color values
            displayDiv.innerHTML=colorstring3;
            //break out of case
            break;
    }

}
//declare the +1 function
function changeValue5(event) {
    //get access to the display grid
    let displayDiv2=document.querySelector("#display");
    //get access to the color div
    let color2=document.querySelector("#changer");
    //get the color attribute from the button that was clicked
    let type2=event.target.getAttribute("data-color");
     //switch cases based off of the color 
    switch(type2) {
        //if the color is red
        case "red":
            //increase value of red by 5
            r=r+5;
            //create a color string
            let colorstring4="rgb("+r+","+g+","+b+")";
            //create a color string
            color2.style.backgroundColor=colorstring4;
            //update listed color values
            displayDiv2.innerHTML=colorstring4;
            //break out of case
            break;
        //if the color is green
        case "green":
            //increase green by 5
            g=g+5;
            //create a color string
            let colorstring5="rgb("+r+","+g+","+b+")";
            //set color grid to the new value of the color
            color2.style.backgroundColor=colorstring5;
            //update listed color values
            displayDiv2.innerHTML=colorstring5;
            //break out of case
            break;

        //if the color is blue
        case "blue":
            //increase the value of blue by 5
            b=b+5;
            //create a color string
            let colorstring6="rgb("+r+","+g+","+b+")";
            //set color grid to the new value of the color
            color2.style.backgroundColor=colorstring6;
            //update listed color values
            displayDiv2.innerHTML=colorstring6;
            //break out of case
            break;
    }

}
//declare the +10 function
function changeValue10(event) {
     //get access to the display grid
    let displayDiv3=document.querySelector("#display");
    //get access to the color div
    let color3=document.querySelector("#changer");
    //get the color attribute from the button that was clicked
    let type3=event.target.getAttribute("data-color");
    //switch cases based off of the color 
    switch(type3) {
        //if the color is red
        case "red":
            //increase value of red by 1
            r=r+10;
            //create a color string
            let colorstring7="rgb("+r+","+g+","+b+")";
            //create a color string
            color3.style.backgroundColor=colorstring7;
            //update listed color values
            displayDiv3.innerHTML=colorstring7;
            //break out of case
            break;

        //if the color is green
        case "green":
            //increase value of green by 10
            g=g+10;
            //create a color string
            let colorstring8="rgb("+r+","+g+","+b+")";
            //set color grid to the new value of the color
            color3.style.backgroundColor=colorstring8;
             //update listed color values
            displayDiv3.innerHTML=colorstring8;
            //break out of case
            break;
        //if the color is blue
        case "blue":
            //increase the value of blue by 10
            b=b+10;
            //create a color string
            let colorstring9="rgb("+r+","+g+","+b+")";
            //set color grid to the new value of the color
            color3.style.backgroundColor=colorstring9;
            //update listed color values
            displayDiv3.innerHTML=colorstring9;
            //break out of case
            break;
    }

}

