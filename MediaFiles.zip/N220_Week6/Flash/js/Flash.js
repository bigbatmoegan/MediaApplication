// N220 Section 28299
// Jeremy Morgan
// Week 6: Events
// October 7 2019


'use strict';

//define the set of questions and answers
let questions = [{question: "What is your favorite color?", answer: "Blue. No! Yelloooooowww..."},

                //define question 2
                 {question: "What is your favorite food?", answer: "Buffalo Chicken Wings!"},
                
                 //define question 3
                 {question: "What is your major?", answer: "Computer Sciecne" }
                ]

//define the load questions function
function loadQuestions() {
    
    //create a variable to use through a loop
    let x=0;
    
    //loop through the questions
    for(x; x<questions.length; x++) {

        //create a button for each quetion
        let button=document.createElement("BUTTON");

        //make the innerHTML of the button the question
        button.innerHTML=questions[x].question;

        //give an attribute to store the question number
        button.setAttribute("data-question", x+1);

        //add an attribute containing the answer
        button.setAttribute("data-answer", questions[x].answer);

        //add button to the body
        document.body.appendChild(button);

        //add event listener
        button.addEventListener("click", function() {

            //run function of showing answer when clicked
            showAnswer(event)
        });
    }
}


//define showAnswer function
function showAnswer(event) {

    //Access the output div of the body
    let myDiv=document.querySelector("#output");

    //access the question number of the button that was clicked
    let myButton=event.target.getAttribute("data-question");

    //display the answer in the output div
    myDiv.innerHTML=questions[myButton-1].answer;
}