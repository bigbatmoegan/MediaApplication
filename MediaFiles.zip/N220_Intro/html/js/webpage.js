//  N220 Section 28299
//  Jeremy Morgan
//  Week 1: Intro Lab
//  August 27 2019

'use strict';

function main() {

    document.write("Hello World!");
    

}