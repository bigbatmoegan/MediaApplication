//
//  N220 Section 28299
//  Jeremy Morgan
//  Week 13: Personal object composition
//  02 December 2019
//

//define class ghost
class Ghost {
    //constructor given random velocity
    constructor(xvel, yvel) {
        //starting value of x since all start in the same spot
        this._x=400;
        //starting value of y since all start in the same spot
        this._y=600;
        //get passed in x velocity
        this._xvel=xvel;
        //get passed in y velocity
        this._yvel=yvel;
        //assign a random size to the circle
        this._radius=random(10,30);
    }

    //function that moves the ghosts
    move() {
        //increase spot by object's x velocity
        this._x+=this._xvel;
        //increase spot by object's y velocity
        this._y+=this._yvel;
        //Ideally this would have made one color and stayed
        //constant as the ball moved, but it loops and honestly
        //looks coller this way
        //generate random red value
        let r=random(0,255);
        //make g always be 255 so different shades of green
        let g=255;
        //generate random blue value
        let b=random(0,255);
        //fill by generated color
        fill(r,g,b);
        //draw circle
        circle(this._x, this._y, this._radius);
    }
}

//system to hold ghosts
const system = {
    //array to hold ghosts
    ghosts : [],
}

//setup function
function setup() {
    //draw canvas
    createCanvas(800, 600);
    //loop to create ghosts
    for(let x=0; x<75;x++) {
        //make ghosts and fill into array
        system.ghosts.push(new Ghost(random(-2,2), random(-1, -8)));
    }
    
}

//draw function
function draw() {
    //draw background 
    background(128);
    //iterate through array
    for( let x=0; x< system.ghosts.length; x++) {
        //move each ghost
        system.ghosts[x].move();
    }
    //color in the ghost trap box
    fill(255,0,0);
    //draw the rectangle
    rect(350,550,100,90);

    fill(255);

    rect(0,0, 70, 20);
    rect(70, 0, );

    circle(400, 300, 20);
}