// N220 Section 28299
// Jeremy Morgan
// Week 4: DOM Manipulation and CSS
// September 22 2019

'use strict';

function main() {
    for(let x=0; x<3; x++) {
        let myDiv=document.querySelector("#tower");

        let myDiv2=document.createElement("div");
        myDiv2.style.height= size(x)
        myDiv2.style.width= size(x);
        myDiv2.style.backgroundColor="red";
        myDiv2.style.marginBottom="5px"
        myDiv.appendChild(myDiv2);
    }

}

function size(x) {
    if(x==0) {
        return 100;
    }
    else if(x==1) {
        return 200;
    }
    else {
        return 300;
    }
}