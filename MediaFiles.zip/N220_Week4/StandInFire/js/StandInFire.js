// N220 Section 28299
// Jeremy Morgan
// Week 4: DOM Manipulation and CSS
// September 22 2019

'use strict';

function makeRed() {
    let myDiv= document.querySelector("#block");
    myDiv.style.backgroundColor= "red";
}

function makeYellow() {
    let myDiv= document.querySelector("#block");
    myDiv.style.backgroundColor= "yellow";
}
function main() {
    

}