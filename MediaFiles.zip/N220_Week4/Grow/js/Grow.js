// N220 Section 28299
// Jeremy Morgan
// Week 4: DOM Manipulation and CSS
// September 22 2019

'use strict';
let numberOfClicks=1;
function changeSize() {
    let myDiv= document.querySelector("#grower");
    myDiv.style.height= maths(numberOfClicks);
    myDiv.style.width= maths(numberOfClicks);
    numberOfClicks++;
}


function maths(numberOfClicks) {
    if(numberOfClicks==1)
    {
        let size=100*1.10
        return size;
    }
    else
    {
        let size=100*1.10;
        for(let x=0; x<numberOfClicks; x++)
        {
            size=size*1.10
        }
        return size;
    }
}
function main() {
    

}