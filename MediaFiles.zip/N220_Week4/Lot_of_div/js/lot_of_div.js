// N220 Section 28299
// Jeremy Morgan
// Week 4: DOM Manipulation and CSS
// September 22 2019

'use strict';

function main() {
    for(let x=0; x<100; x++) {
        let myDiv=document.querySelector("#speck");

        let myDiv2=document.createElement("div");
        myDiv2.style.backgroundColor=color();
        myDiv2.style.left=Math.round(Math.random())
        myDiv2.style.height= "20px";
        myDiv2.style.width= "20px";
        myDiv.appendChild(myDiv2);
    }

}

function color() {
    let red=Math.round(Math.random() * 255);
    let green=Math.round(Math.random() * 255);
    let blue=Math.round(Math.random() * 255);

    let string="rgb("+red+","+green+","+blue+")";
    return string;
}