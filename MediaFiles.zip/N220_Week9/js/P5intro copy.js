//
//  N220 Section 28299
//  Jeremy Morgan
//  Week 9: Intro to P5
//  30 October 2019
//

function setup() {
    
    //create canvas
    createCanvas(800, 600);

    //color background blue
    background(0, 0, 255);
    
    fill(0);
    ellipse(400, 200, 75, 75);
    strokeWeight(10);
    line(400, 200, 400, 350);
    line(400, 350, 350, 400);
    line(400, 350, 450, 400);
    line(400, 275, 325, 300);
    line(400, 275, 475, 300);

    strokeWeight(0);
    fill(255, 255, 0);
    ellipse(385, 190, 10, 10);
    ellipse(415, 190, 10, 10);

    arc(400, 210, 35, 35, 0, PI);

}