//
//  N220 Section 28299
//  Jeremy Morgan
//  Week 9: Intro to P5
//  30 October 2019
//

function setup() {

   //create canvas
   createCanvas(800, 600);

   //color background blue
   background(0, 0, 255);

   //change stroke to 5 for line
   strokeWeight(5);

   //change color to gray for line
   stroke(128);

   //make line from corner to corner
   line(800, 0, 0, 600);

   //set stroke of circle in upper right to black
   stroke(0, 0, 0);

   //set stroke weight of red cirle to 3
   strokeWeight(3);

   //color circle red
   fill(255, 0, 0);

   //create circle in upper right corner
   ellipse(725, 75, 100);

   //change stroke weight to 2
   strokeWeight(2);

   //change stroke color to yellow
   stroke(255, 255, 0);

   //color square green
   fill(0, 255, 0);

   //make square in bottom left
   rect(50, 450, 100, 100);
}