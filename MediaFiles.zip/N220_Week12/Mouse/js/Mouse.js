//
//  N220 Section 28299
//  Jeremy Morgan
//  Week 12: Animation and Functions
//  17 November 2019
//

//for some reason, mine was very figity. like not smooth like the ball one. couldn't figure out why.
//declare ball
let ball = {
    //radius of the circle
    _radius: 75,
    //starting x value
    _xPos: 0,
    //starting y value
    _yPos: 0,
    //ball velocity
    _velocity: 08,
    //ball x speed
    _speedx: 03,
    //ball x speed
    _speedy: 03

}

//setup function
function setup() {
    //create the canvas
    createCanvas(800,600);

}

function draw() {

    //create mouse object
    let mouseLoc= {
        //mouse x
        x: mouseX,
        //mouse y
        y: mouseY
    };
    //color background
    background(120);
    //check if near 7 pixels 
    if((mouseLoc.x-ball._xPos<7 && mouseLoc.x-ball._xPos>=-7) && (ball._yPos-mouseLoc.y<7 && ball._yPos-mouseLoc.y>=-7) && (mouseLoc.y-ball._yPos<7 && mouseLoc.y-ball._yPos>=-7) && (ball._xPos-mouseLoc.x<7 && ball._xPos-mouseLoc.x>=-7) ) {
        //color red
        fill(255,0,0);
        //draw new circle
        circle(ball._xPos, ball._yPos, ball._radius);
    }
    else {
        //color in ball
        fill(0,0,0);
        //draw ball
        circle(ball._xPos, ball._yPos, ball._radius);
    }
    // move closer to mouse if on the right of mouse
    if(ball._xPos < mouseLoc.x) {
        //go right
        ball._xPos=ball._xPos+ball._speedx;
        //used to make the ball stop figiting over and over in place and get stuck constantly going in this if statement
        if(ball._xPos = mouseLoc.x) {
            //stop figiting
            ball._xPos=ball._xPos;
        }
    }
    // move closer to mouse if on the left of mouse
    else if(ball._xPos > mouseLoc.x) {
        ball._xPos=ball._xPos-ball._speedx;
        //used to make the ball stop figiting over and over in place and get stuck constantly going in this if statement
        if(ball._xPos = mouseLoc.x) {
            //stop figiting
            ball._xPos=ball._xPos;
        }
    }
    // move closer to mouse if under mouse
    else if(ball._yPos < mouseLoc.y) {
        ball._yPos=ball._yPos+ball._speedy;
       
    }
    // move closer to mouse if above mouse
    else if(ball._yPos > mouseLoc.y) {
        ball._yPos=ball._yPos-ball._speedy;
       
    }
}