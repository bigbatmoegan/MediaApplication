//
//  N220 Section 28299
//  Jeremy Morgan
//  Week 12: Animation and Functions
//  17 November 2019
//

//declare ball
let ball = {
    //radius of the circle
    _radius: 75,
    //starting x value
    _xPos: 0,
    //starting y value
    _yPos: 300,
    //ball velocity
    _velocity: 08,
    //ball x speed
    _speedx: 06,
    //ball x speed
    _speedy: 06

}

//declare rectangle
let rectangle = {
    //rectangle x position
    x: 0,
    //y position
    y: 500,
    //width
    width: 800,
    //height
    height: 200
}
//setup function
function setup() {
    //create the canvas
    createCanvas(800,600);

}

function draw() {

    //color background
    background(120);
    //color in ball
    fill(0,0,255);
    //draw ball
    circle(ball._xPos, ball._yPos, ball._radius);
    //color in the rectangle
    fill(255,0,0);
    //draw rectangle
    rect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    //check if the ball is at the far left of screen
    if(ball._xPos > 800) {
        //change magnitude so the ball bounces back
        ball._speedx=ball._speedx * -1;
    }
    //check if the ball is at the far right of the screen
    else if(ball._xPos < 0) {
        //change magnitude so the ball bounces back
        ball._speedx=ball._speedx * -1;
    }
    //check if the ball is at the top of the screen
    else if(ball._yPos < 0) {
        //change magnitude so the ball bounces back
        ball._speedy=ball._speedy * -1;
    }
    //check if hitting the rectangle
    else if(rectHit(rectangle, ball)) {
        //change magnitude
        ball._speedy=ball._speedy=-1;
    }
    //update the x location of the ball
    ball._xPos=ball._xPos+ball._speedx;
    //update the y location of the ball
    ball._yPos=ball._yPos+ball._speedy;
}

//detect if hitting rectangle
function rectHit(r, b) {
    //find the top (offset by 35 since otherwise there was
    //a weitd clipping effect going on where part of the ball
    //was inside rectangle before bouncing, so eyeballed it to
    //bounce the moment it hit))
    let top= r.y-35;
    //see if the y value is less
    if(ball._yPos < top) {
        //if not then dont worry about changing
        return false;
    }
    //if it is return true to change magnitude
    return true;
}