//
//  N220 Section 28299
//  Jeremy Morgan
//  Week 14: Breakout
//  10 December 2019
//

'use strict';

//block class
class Block {
    //constructor using locations for blocks
    constructor(xloc, yloc, colorkey) {
        //blocks x location
        this.x=xloc;
        //blocks y location
        this.y=yloc;
        //blocks set width
        this.width=70;
        //blocks set height
        this.height=20;
        //int used to track color
        this.color=colorkey;
    }

    //draw the blocks
    draw() {
        //set top row to a set color
        if(this.color <=8 ) {
            //pick a color
            fill(0, 0, 128);
            //draw the rectangle
            rect(this.x, this.y, this.width, this.height);
        }
        //set second row to a set color
        else if(this.color >8 && this.color <=17) {
            //set to a color
            fill(0, 0, 255);
            //draw the rectangle
            rect(this.x, this.y, this.width, this.height);
        }
        //set the thrid row to a set color
        else if(this.color >17 && this.color <=26) {
            //pick a color
            fill(0, 128, 0);
            //draw the rectangle
            rect(this.x, this.y, this.width, this.height);
        }
        //set the fourth row to a set color
        else if(this.color >26 && this.color <=35) {
            //pick a color
            fill(255, 182, 0);
            //draw the rectangle
            rect(this.x, this.y, this.width, this.height);
        }
        else //set the very bottom row
        {
            //set the color
            fill(255, 255, 0);
            //draw the rectangle
            rect(this.x, this.y, this.width, this.height);
        }
        //draw the rectangle
    }
}
//paddle class
class Paddle {
    //paddle constructor
    constructor(xloc) {
        //paddle x location
        this.x=xloc;
        //fixed y location for paddle
        this.y=500;
        //paddle's set width
        this.width=70;
        //paddle's set height
        this.height=20;

    }
    //moving the paddle
    move(_x,) {
        //dont let the paddle leave the screen
        if(_x >=560) {
            this.x=560;
            //color paddle green
            fill(0,255,0);
            //draw paddle
            rect(this.x, this.y, this.width, this.height);
        }
        //dont let the paddle leave the scren
        else if(_x <= 0) {
            this.x=0;
            //color paddle green
            fill(0,255,0);
            //draw paddle
            rect(this.x, this.y, this.width, this.height);
        }
        else {
            //set the x location based off the mouse
            this.x=_x;
            //color paddle green
            fill(0,255,0);
            //draw paddle
            rect(this.x, this.y, this.width, this.height);
        }
    }
}

//ball class
class Ball {
    //ball constructor with locations
    constructor(xloc, yloc) {
        //ball x location
        this.x=xloc;
        //ball y location
        this.y=yloc;
        //ball set radius
        this.radius=20;
        //ball moving x speed
        this.xvel=4;
        //ball moving y speed
        this.yvel=4;
    }

    //move the ball
    move() {
        //update x location
        this.x=this.x+this.xvel;
        //update y location
        this.y=this.y+this.yvel;
        //color in red
        fill(255,0,0);
        //draw the circle
        circle(this.x, this.y, this.radius);
    }
}
//systems to hold necessary classes
const system = {
    //block array
    blocks: [],
    //ball array
    balls: [],
    //paddle array
    paddles: [],
    //score array
    scores: []
}

//score class
class score {
    //current score
    _score=0;
    //update score
    update() {
        //increase by 100
        this._score=this._score+100;
    }
}
//setup function
function setup() {
    //draw canvas
    createCanvas(630, 600);
    //loop to create ghosts
    for(let x=0; x<45;x++) {
        //make ghosts and fill into array
        system.blocks.push(new Block((70*(x%9)), 40+floor(x/9)*20, x));
    }
    console.log(system.blocks.length);
    //add one ball to the game
    system.balls.push(new Ball(0, 400));
    //add the paddle to the game
    system.paddles.push(new Paddle(mouseY));
    //set the score at 0
    system.scores.push(new score())
}

function draw() {
    //draw background 
    background(128);
    for(let x=0; x<system.blocks.length;x++) {
        //make ghosts and fill into array
        system.blocks[x].draw();
    }
    //color in the text for the score
    fill(0);
    //make a string containing the score
    let scoreString="SCORE: "+system.scores[0]._score;
    //show the text to the screen
    text(scoreString, 10, 10);
    //move the ball
    system.balls[0].move();
    //move the mosue
    system.paddles[0].move(mouseX);
    //check if hit on x edges
    if(system.balls[0].x>630 || system.balls[0].x<=0) {
        //change the x direction of the ball
        system.balls[0].xvel=system.balls[0].xvel*-1;
    }
    //check if hit on y edges
    else if(system.balls[0].y>600 || system.balls[0].y<=0) {
        //change the y direction of the ball
        system.balls[0].yvel=system.balls[0].yvel*-1;
    }
    //check if the ball is hitting the blocks
    for(let x=system.blocks.length-1; x>=0 ;x--) {
        //check for a hit on any given block in the array
        let hit=collideRectCircle(
            system.blocks[x].x, system.blocks[x].y,
            system.blocks[x].width, system.blocks[x].height,
            system.balls[0].x, system.balls[0].y,
            system.balls[0].radius
        );
        //if the hit is successful
        if(hit) {
            //delete that block from the array
            system.blocks.splice(x, 1);
            //update the score
            system.scores[0].update();
            //bounce back down from the block
            system.balls[0].yvel=system.balls[0].yvel*-1;
        }
    }
    //check if hitting paddle
    let hit2=collideRectCircle(
        system.paddles[0].x, system.paddles[0].y,
        system.paddles[0].width, system.paddles[0].height,
        system.balls[0].x, system.balls[0].y,
        system.balls[0].radius
    );
    //if hitting the paddle
    if(hit2) {
        //bounce back up
        system.balls[0].yvel=system.balls[0].yvel*-1;
    }
    //check if the block array is empty
    if(system.blocks.length==0) {
        //create a new string containing final score
        let end="GAME OVER! SCORE: "+system.scores[0]._score;
        //show score to user and end the game
        text(end, 315, 300);
    }
}