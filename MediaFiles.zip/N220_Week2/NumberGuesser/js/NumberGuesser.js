// N220 Section 28299
// Jeremy Morgan
// Week 2: Program Flow Control
// September 6 2019


'use strict';

function main() {

    var answer=Math.round(Math.random() * 20);
    document.getElementById("submitnumber").onclick=function()
    {
        var guess=document.getElementById("userGuess").value;
        if(answer==guess)
        {
            alert("You guessed right!");
        }
        else if(guess>answer)
        {
            alert("Too high, enter a smaller number");
        }
        else
        {
            alert("Too low, enter a larger number");
        }
    }
    

}