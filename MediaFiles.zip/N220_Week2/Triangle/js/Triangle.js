// N220 Section 28299
// Jeremy Morgan
// Week 2: Program Flow Control
// September 6 2019


'use strict';

function main() {

    var hashtag = "#"
    var i;
    for(i=0; i<7; i++)
    {
        document.write(hashtag);
        document.write('<br/>');
        hashtag=hashtag+"#";
    }
    

}