// N220 Section 28299
// Jeremy Morgan
// Week 2: Program Flow Control
// September 6 2019

'use strict';

function main() {

   var x;
   var number=0;
   for(x=0; x<101; x++)
   {
        if(number%3==0 && number%5==0)
        {
            document.write("fizzbuzz");
        }
        else
        {
            if(number%3==0)
            {
                document.write("fizz");
            }
            else if(number%5==0)
            {
                document.write("buzz");
            }
            else
            {
                document.write(number);
            }
       }
       number++;
       document.write('<br/>');
   }
    

}