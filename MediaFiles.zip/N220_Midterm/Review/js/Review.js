// N220 Section 28299
// Jeremy Morgan
// Week 7: Midterm Review
// October 12 2019


'use strict';

//declare function
function randomColor() {
    //get access to the color bar
    let myDiv=document.querySelector("#colorbar");
    //get the current r value from the attribute
    let r=myDiv.getAttribute("data-red");
    //get the current g value from the attribute
    let g=myDiv.getAttribute("data-green");
    //get the current b value from the attribute
    let b=myDiv.getAttribute("data-blue");
    //pick which to change randomly
    let random=Math.floor(Math.random()*3);
    console.log(random);
    //if random=0, change red
    if(random==0) {
        //generate a new color
        r=Math.floor(Math.random() *256);
    }
    //if random=1 change green
    else if(random==1) {
        //generate a new color
        g=Math.floor(Math.random() *256);
    }
    //if random=2, change blue
    else {
        //generate a new color
        b=Math.floor(Math.random() *256);
    }
    //set the new color value
    myDiv.setAttribute("data-red", r);
    //set the new color value
    myDiv.setAttribute("data-green", g);
    //set the new color value
    myDiv.setAttribute("data-blue", b);
    //create a color string
    let colorstring="rgb("+r+","+g+","+b+")";
    //set the new background color
    myDiv.style.backgroundColor=colorstring;
    //access the output div
    let output=document.querySelector("#output");
    //show the new color values
    output.innerHTML=colorstring;

}