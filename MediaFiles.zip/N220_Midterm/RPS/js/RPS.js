// N220 Section 28299
// Jeremy Morgan
// Week 7: Midterm Review
// October 12 2019


'use strict';

//declare game function
function playGame(event) {
    
    //0=rock, 1=paper, 2=scissors, so 0 beats 2 means rock beats scissors
    //get the button that was clicked
    let user=event.target.getAttribute("data-value");

    //get the computers answer
    let computer=Math.floor(Math.random()*3)
    //switch case based off of user pick
    switch(user) {
        //case they picked rock
        case "0":
            //if computer picks paper, it wins
            if(computer==1) {               
                //assign a loss to the user
                gameResult("loss");
            }
            //if computer picks scissors, user wins
            else if(computer==2) {
                //assign user a win
                gameResult("win");
            }
            //if both pick rock, tie
            else {   
                //assign tie
                gameResult("tie");
            }
            //break out of case
            break;
        //if they pick paper
        case "1":
            //if computer picks scissors, it wins
            if(computer==2) {
                //assign a loss to the user
                gameResult("loss");
            }
            //if computer picks rock, user wins
            else if (computer==0) {
                //assign a win to the user
                gameResult("win");
            }
            //if both pick paper
            else {
                //assign a tie
                gameResult("tie");
            }
            //break out of case
            break;
            //if they pick scissors
        case "2":
            //if computer picks rock, it wins
            if(computer==0) {
                //assign a loss to the user
                gameResult("loss");
            }
            //if computer picks paper, user wins
            else if (computer==1) {
                //assign a win to the user
                gameResult("win");
            }
            //if both pick scissors
            else {
                //assign a tie
                gameResult("tie");
            }
            //break out of case
            break;
    }
}

//function to update record
function gameResult(string) {

    //assign a win
    if(string=="win") {
        //get the output div to show who won the game
        let result=document.querySelector("#output");
        //display who won
        result.innerHTML="Winner: User!";
        //get the record div to show the users record
        let record=document.querySelector("#record");
        //access the number of wins
        let record2=record.getAttribute("data-wins");
        //turn it into an int
        let recordInt=parseInt(record2, 10);
        //add one win
        recordInt=recordInt+1;
        //go back to a string
        let recordString=recordInt+"";
        //update the number of wins
        record.setAttribute("data-wins", recordString);
        //show the overall record of the user
        showRecord();
    }
    //assign a loss
    else if(string=="loss") {
        //get the output div to show who won the game
        let result2=document.querySelector("#output");
        //display who won
        result2.innerHTML="Winner: Computer!";
        //get the record div to show the users record
        let record3=document.querySelector("#record");
        //access the numner of losses
        let record4=record3.getAttribute("data-losses");
        //convert to int
        let recordInt2=parseInt(record4, 10);
        //add one loss
        recordInt2=recordInt2+1;
        //go back to string
        let recordString2=recordInt2+"";
        //update the number of losses
        record3.setAttribute("data-losses", recordString2);
        //show the overall record of the user
        showRecord();
    }
    //assign a tie
    else {
        //get the output div to show who won the game
        let result3=document.querySelector("#output");
        //show who won
        result3.innerHTML="Winner: No one!";
        //get the record div to show the users record
        let record5=document.querySelector("#record");
        //access the numner of ties
        let record6=record5.getAttribute("data-ties");
        //convert to int
        let recordInt3=parseInt(record6, 10);
        //add one tie
        recordInt3=recordInt3+1;
        //go back to string
        let recordString3=recordInt3+"";
        //update the number of ties
        record5.setAttribute("data-ties", recordInt3);
        //show the overall record of the user
        showRecord();
    }
}

//write to the record div
function showRecord() {
    //access the record div
    let display=document.querySelector("#record");
    //get the number of wins
    let w=display.getAttribute("data-wins");
    //get the number of losses
    let l=display.getAttribute("data-losses");
    //get the number of ties
    let t=display.getAttribute("data-ties");
    //combine into a formal record string
    let wlt="Record: "+w+"-"+l+"-"+t;
    //update the div to show the record
    display.innerHTML=wlt;
}